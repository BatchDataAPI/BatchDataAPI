function showPanel(eve, id) {
  $(".cnt").hide();
  $(".nav-link").removeClass("active");
  $("#" + eve).addClass("active");
  $("#" + id).show();
  $("#output").html("Please submit the form above");
}

// Function to fetch address verification data
async function addressVerificationData() {
  try {
    // Show the loader
    document.getElementById("loader").style.display = "flex";

    // Get the value from the text box
    const token = document.getElementById("clientToken").value;
    const avAddress = document.getElementById("avAddress").value;
    const avCity = document.getElementById("avCity").value;
    const avState = document.getElementById("avState").value;
    const avZip = document.getElementById("avZip").value;

    if (!token) {
      alert("Please enter an API token.");
      return;
    }

    // Collect validation error messages
    let errors = [];

    if (!avAddress) errors.push("Please enter a address.");
    if (!avCity) errors.push("Please enter a city.");
    if (!avState) errors.push("Please enter a state.");
    if (!avZip) errors.push("Please enter a zip code.");

    // If there are any errors, display them and return
    if (errors.length > 0) {
      alert(errors.join("\n"));
      return;
    }

    const response = await fetch("/api/address-verification", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        requests: [
          {
            street: avAddress,
            city: avCity,
            state: avState,
            zip: avZip,
          },
        ],
      }),
    });
    const data = await response.json();

    // Convert the data to a formatted JSON string
    const formattedData = JSON.stringify(data, null, 2);

    // Display the data in the <pre> element
    document.getElementById("output").textContent = formattedData;
  } catch (error) {
    document.getElementById("output").textContent =
      "Error while fetching data of address";
  } finally {
    // Hide the loader
    document.getElementById("loader").style.display = "none";
  }
}

// Function to fetch phone verification data
async function phoneVerification() {
  try {
    // Show the loader
    document.getElementById("loader").style.display = "flex";

    // Get the value from the text box
    const token = document.getElementById("clientToken").value;
    const pvPhone = document.getElementById("pvPhone").value;

    if (!token) {
      alert("Please enter an API token.");
      return;
    }

    // Collect validation error messages
    let errors = [];

    if (!pvPhone) errors.push("Please enter a phone number.");

    // If there are any errors, display them and return
    if (errors.length > 0) {
      alert(errors.join("\n"));
      return;
    }

    const response = await fetch("/api/phone-verification", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        requests: [pvPhone],
      }),
    });
    const data = await response.json();

    // Convert the data to a formatted JSON string
    const formattedData = JSON.stringify(data, null, 2);

    // Display the data in the <pre> element
    document.getElementById("output").textContent = formattedData;
  } catch (error) {
    document.getElementById("output").textContent =
      "Error while fetching data of phone";
  } finally {
    // Hide the loader
    document.getElementById("loader").style.display = "none";
  }
}

// Function to fetch property Lookup data
async function propertyLookup() {
  try {
    // Show the loader
    document.getElementById("loader").style.display = "flex";

    // Get the value from the text box
    const token = document.getElementById("clientToken").value;
    const plAddress = document.getElementById("plAddress").value;
    const plCity = document.getElementById("plCity").value;
    const plState = document.getElementById("plState").value;
    const plZip = document.getElementById("plZip").value;

    if (!token) {
      alert("Please enter an API token.");
      return;
    }

    // Collect validation error messages
    let errors = [];
    if (!plAddress) errors.push("Please enter a lookup address.");
    if (!plCity) errors.push("Please enter a city.");
    if (!plState) errors.push("Please enter a state.");
    if (!plZip) errors.push("Please enter a zip code.");

    // If there are any errors, display them and return
    if (errors.length > 0) {
      alert(errors.join("\n"));
      return;
    }

    const response = await fetch("/api/property/lookup", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        requests: [
          {
            address: {
              street: plAddress,
              city: plCity,
              state: plState,
              zip: plZip,
            },
          },
        ],
      }),
    });
    const data = await response.json();

    // Convert the data to a formatted JSON string
    const formattedData = JSON.stringify(data, null, 2);

    // Display the data in the <pre> element
    document.getElementById("output").textContent = formattedData;
  } catch (error) {
    document.getElementById("output").textContent =
      "Error while fetching data of property lookup";
  } finally {
    // Hide the loader
    document.getElementById("loader").style.display = "none";
  }
}

// Function to fetch address geocode data
async function addressGeocode() {
  try {
    // Show the loader
    document.getElementById("loader").style.display = "flex";

    // Get the value from the text box
    const token = document.getElementById("clientToken").value;
    const agAddress = document.getElementById("agAddress").value;

    if (!token) {
      alert("Please enter an API token.");
      return;
    }

    // Collect validation error messages
    let errors = [];
    if (!agAddress) errors.push("Please enter a address.");

    // If there are any errors, display them and return
    if (errors.length > 0) {
      alert(errors.join("\n"));
      return;
    }

    const response = await fetch("/api/address/geocode", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        requests: [
          {
            address: agAddress,
          },
        ],
      }),
    });
    const data = await response.json();

    // Convert the data to a formatted JSON string
    const formattedData = JSON.stringify(data, null, 2);

    // Display the data in the <pre> element
    document.getElementById("output").textContent = formattedData;
  } catch (error) {
    document.getElementById("output").textContent =
      "Error while fetching data of address geocode";
  } finally {
    // Hide the loader
    document.getElementById("loader").style.display = "none";
  }
}

// Function to fetch property skip trace data
async function propertySkipTrace() {
  try {
    // Show the loader
    document.getElementById("loader").style.display = "flex";

    // Get the value from the text box
    const token = document.getElementById("clientToken").value;
    const sktAddress = document.getElementById("sktAddress").value;
    const sktCity = document.getElementById("sktCity").value;
    const sktState = document.getElementById("sktState").value;
    const sktZip = document.getElementById("sktZip").value;

    if (!token) {
      alert("Please enter an API token.");
      return;
    }

    // Collect validation error messages
    let errors = [];
    if (!sktAddress) errors.push("Please enter a address.");
    if (!sktCity) errors.push("Please enter a city.");
    if (!sktState) errors.push("Please enter a state.");
    if (!sktZip) errors.push("Please enter a zip code.");

    // If there are any errors, display them and return
    if (errors.length > 0) {
      alert(errors.join("\n"));
      return;
    }

    const response = await fetch("/api/property/skip-trace", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        requests: [
          {
            propertyAddress: {
              street: sktAddress,
              city: sktCity,
              state: sktState,
              zip: sktZip,
            },
          },
        ],
      }),
    });
    const data = await response.json();

    // Convert the data to a formatted JSON string
    const formattedData = JSON.stringify(data, null, 2);

    // Display the data in the <pre> element
    document.getElementById("output").textContent = formattedData;
  } catch (error) {
    document.getElementById("output").textContent =
      "Error while fetching data of property skip trace";
  } finally {
    // Hide the loader
    document.getElementById("loader").style.display = "none";
  }
}

// Call the function when needed, on button click
document.addEventListener("DOMContentLoaded", () => {
  const addressVerificationButton = document.getElementById(
    "addressVerificationButton"
  );
  const phoneVerificationButton = document.getElementById(
    "phoneVerificationButton"
  );

  const propertyLookupButton = document.getElementById("propertyLookupButton");

  const addressGeocodeButton = document.getElementById("addressGeocodeButton");

  const propertySkipTraceButton = document.getElementById(
    "propertySkipTraceButton"
  );

  if (addressVerificationButton) {
    addressVerificationButton.addEventListener(
      "click",
      addressVerificationData
    );
  }

  if (phoneVerificationButton) {
    phoneVerificationButton.addEventListener("click", phoneVerification);
  }

  if (propertyLookupButton) {
    propertyLookupButton.addEventListener("click", propertyLookup);
  }

  if (addressGeocodeButton) {
    addressGeocodeButton.addEventListener("click", addressGeocode);
  }

  if (propertySkipTraceButton) {
    propertySkipTraceButton.addEventListener("click", propertySkipTrace);
  }
});
