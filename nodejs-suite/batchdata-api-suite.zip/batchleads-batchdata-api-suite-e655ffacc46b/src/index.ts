import express from "express";
import path from "path";
import axios from "axios";

const app = express();
const port = 3000;
app.use(express.json());

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, "../public")));

// Route to serve the HTML file
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"));
});

/**
 * API route to fetch data from a address/verify API
 */
app.post("/api/address-verification", async (req, res) => {
  const url = "https://api.staging.batchdata.com/api/v1/address/verify";
  const token = req.headers.authorization?.split(" ")[1];
  const payload = req.body;
  if (!token) {
    return res.status(400).json({ error: "No token provided" });
  }

  if (!payload) {
    return res.status(400).json({ error: "No payload provided" });
  }

  try {
    const response = await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    // Send the response data back to the client
    res.json(response.data);
  } catch (error: any) {
    console.error("Error fetching address data:", error);
    res.status(500).send(error?.response?.data);
  }
});

/**
 * API route to fetch data from a phone/verify API
 */
app.post("/api/phone-verification", async (req, res) => {
  const url = "https://api.staging.batchdata.com/api/v1/phone/verification";
  const token = req.headers.authorization?.split(" ")[1];
  const payload = req.body;
  if (!token) {
    return res.status(400).json({ error: "No token provided" });
  }

  if (!payload) {
    return res.status(400).json({ error: "No payload provided" });
  }

  try {
    const response = await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    // Send the response data back to the client
    res.json(response.data);
  } catch (error: any) {
    console.error("Error fetching phone data:", error);
    res.status(500).send(error?.response?.data);
  }
});

/**
 * API route to fetch data from a property/lookup API
 */
app.post("/api/property/lookup", async (req, res) => {
  const url =
    "https://api.staging.batchdata.com/api/v1/property/lookup/all-attributes";
  const token = req.headers.authorization?.split(" ")[1];
  const payload = req.body;
  if (!token) {
    return res.status(400).json({ error: "No token provided" });
  }

  if (!payload) {
    return res.status(400).json({ error: "No payload provided" });
  }

  try {
    const response = await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    // Send the response data back to the client
    res.json(response.data);
  } catch (error: any) {
    console.error("Error fetching property lookup data:", error);
    res.status(500).send(error?.response?.data);
  }
});

/**
 * API route to fetch data from a address/geocode API
 */
app.post("/api/address/geocode", async (req, res) => {
  const url = "https://api.staging.batchdata.com/api/v1/address/geocode";
  const token = req.headers.authorization?.split(" ")[1];
  const payload = req.body;
  if (!token) {
    return res.status(400).json({ error: "No token provided" });
  }

  if (!payload) {
    return res.status(400).json({ error: "No payload provided" });
  }

  try {
    const response = await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    // Send the response data back to the client
    res.json(response.data);
  } catch (error: any) {
    console.error("Error fetching address geocode data:", error);
    res.status(500).send(error?.response?.data);
  }
});

/**
 * API route to fetch data from a property/skip-trace API
 */
app.post("/api/property/skip-trace", async (req, res) => {
  const url = "https://api.staging.batchdata.com/api/v1/property/skip-trace";
  const token = req.headers.authorization?.split(" ")[1];
  const payload = req.body;
  if (!token) {
    return res.status(400).json({ error: "No token provided" });
  }

  if (!payload) {
    return res.status(400).json({ error: "No payload provided" });
  }

  try {
    const response = await axios.post(url, payload, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    // Send the response data back to the client
    res.json(response.data);
  } catch (error: any) {
    console.error("Error fetching property skip-trace data:", error);
    res.status(500).send(error?.response?.data);
  }
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
