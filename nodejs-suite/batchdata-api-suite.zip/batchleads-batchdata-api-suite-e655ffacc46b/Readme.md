# Project Title

BATCHDATA-API-SUITE

---

## Requirements

You will need Node.js and a node global package, npm installed in your environement.

---

## Install

    $ git clone https://bitbucket.org/batchleads/batchdata-api-suite/src/master/
    $ cd batchdata-api-suite
    $ npm install

## Running the project

    $ npm start || npm run start:dev
